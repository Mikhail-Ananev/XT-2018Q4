﻿namespace Epam.UsersAndAwards.Entities
{
    public class Award
    {
        public int Id { get; set; }

        public string Title { get; set; }
    }
}
