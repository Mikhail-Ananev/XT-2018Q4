﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Epam.Task02.Game
{
    public class Program
    {
        public const int MapWidth = 200;
        public const int MapHeight = 100;

        public static void Main(string[] args)
        {
            var rand = new Random();
            Console.WriteLine("Hello! It`s your first game! Congratulations!");
            Console.WriteLine("If nothing happens - you have to write the code to make it work...");
        }
    }
}
